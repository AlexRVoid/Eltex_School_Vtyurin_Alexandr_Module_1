#!/bin/bash

# Получаем имя скрипта без полного пути
SCRIPT_NAME="$(basename "$0")"

# 1. Проверка на имя template_task.sh
if [[ "$SCRIPT_NAME" == "template_task.sh" ]]; then
    echo "я бригадир, сам не работаю"
    exit 0
fi

WORKDIR="$(dirname "$0")"
LOGFILE="${WORKDIR}/report_${SCRIPT_NAME}.log"

# 2. Логирование старта
echo "$(date '+%Y-%m-%d %H:%M:%S') [$$] Скрипт запущен" >> "$LOGFILE"

# 3. Динамический поиск именованного канала cuckoo.sh через procfs
FIFO_PATH=""
for p in /proc/[0-9]*; do
    if [[ -r "$p/cmdline" ]] && grep -qa "cuckoo.sh" "$p/cmdline" 2>/dev/null; then
        FIFO_PATH=$(tr '\0' '\n' < "$p/cmdline" | grep '^--pishitesuda=' | head -n 1 | cut -d= -f2)
        break
    fi
done

if [[ -z "$FIFO_PATH" || ! -p "$FIFO_PATH" ]]; then
    echo "Ошибка: канал cuckoo.sh не найден через procfs!" >> "$LOGFILE"
    exit 1
fi

# 4. Отправка запроса в канал и чтение ответа N
echo "${SCRIPT_NAME}[$$]: how much time do I have?" > "$FIFO_PATH"
read -r N < "$FIFO_PATH"

# 5. Ожидание полученного времени
sleep "$N"

# 6. Логирование завершения
echo "$(date '+%Y-%m-%d %H:%M:%S') [$$] Скрипт завершился, работал ${N} секунд." >> "$LOGFILE"
