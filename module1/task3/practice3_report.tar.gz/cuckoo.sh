#!/bin/bash

LOGFILE="$(pwd)/cuckoo.log"
FIFO=""

# 1. Парсинг параметра запуска --pishitesuda=
for arg in "$@"; do
    case "$arg" in
        --pishitesuda=*)
            FIFO="${arg#*=}"
            ;;
    esac
done

if [[ -z "$FIFO" ]]; then
    echo "Ошибка: укажите именованный канал через --pishitesuda=/абсолютный/путь" >&2
    exit 1
fi

# 2. Обработчик сигналов (SIGTERM и SIGINT)
cleanup() {
    echo "$(date '+%Y-%m-%d %H:%M:%S') Shutdown!" >> "$LOGFILE"
    rm -f "$FIFO"
    exit 0
}
trap cleanup SIGTERM SIGINT

# 3. Создание именованного канала
[[ -p "$FIFO" ]] || mkfifo "$FIFO"

# 4. Фиксация запуска
echo "$(date '+%Y-%m-%d %H:%M:%S') Startup!" >> "$LOGFILE"

# 5. Цикл обработки запросов через FIFO
while true; do
    if read -r line < "$FIFO"; then
        # Проверяем шаблон "NAME[PID]: how much time do I have?"
        if [[ "$line" =~ ^(.*)\[([0-9]+)\]:\ how\ much\ time\ do\ I\ have\?$ ]]; then
            NAME="${BASH_REMATCH[1]}"
            PID="${BASH_REMATCH[2]}"
            
            # Генерация числа N от 2 до 10
            N=$(( RANDOM % 9 + 2 ))
            
            # Возврат числа обратно в канал для клиента
            echo "$N" > "$FIFO"
            
            # Логирование события
            echo "$(date '+%Y-%m-%d %H:%M:%S') ${NAME}[${PID}] ${N}" >> "$LOGFILE"
        fi
    fi
done
