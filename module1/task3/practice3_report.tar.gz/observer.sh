#!/bin/bash

WORKDIR="$(dirname "$0")"
CONF="${WORKDIR}/observer.conf"
LOGFILE="${WORKDIR}/observer.log"

if [[ ! -f "$CONF" ]]; then
    exit 0
fi

while read -r script_name; do
    # Пропускаем пустые строки и комментарии
    [[ -z "$script_name" || "$script_name" =~ ^# ]] && continue
    
    # Проверяем наличие запущенного процесса в /proc
    is_running=0
    for p in /proc/[0-9]*; do
        if [[ -r "$p/cmdline" ]] && grep -qa "$script_name" "$p/cmdline" 2>/dev/null; then
            is_running=1
            break
        fi
    done
    
    # Если процесс не найден в /proc — запускаем в фоне
    if [[ $is_running -eq 0 ]]; then
        echo "$(date '+%Y-%m-%d %H:%M:%S') Перезапуск $script_name" >> "$LOGFILE"
        nohup "${WORKDIR}/${script_name}" >/dev/null 2>&1 &
    fi
done < "$CONF"
